import React from 'react';
import Header from '../header/header';

const Blog = () =>{
    return <div>
        Healthcare</div>
}

export default Blog;