import React from 'react';
import Header from '../header/header';

const Home = () =>{
    return <div>
        Home</div>
}

export default Home;