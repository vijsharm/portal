import React from 'react';
import Header from '../header/header';

const Tips = () =>{
    return <div>
        Tips</div>
}

export default Tips;