import React from 'react';
import Header from '../header/header';

const Healthcare = () =>{
    return <div>
        Healthcare</div>
}

export default Healthcare;